#!/bin/sh
. /usr/share/debconf/confmodule

installation_progress_log=/var/log/progress

installation_progress_warn()
{
	logger -t installation-progress "warning: $@"
}

installation_progress_http()
{
	local url status
	status="$1"

	# netcfg was not configured yet
	if [ ! -f /etc/network/interfaces ]; then
		installation_progress_warn "network is not ready"
		return
	fi

	if ! db_get installation-progress/url; then
		installation_progress_warn \
			"installation-progress/url is not set"
		return
	fi
	url="$RET"
	uuid="$(cat /sys/class/dmi/id/product_uuid)"
	url="$url/$uuid"

	# We don't really care what happens to wget, if it doesn't succeed, there is
	# not much we can do about it anyway
	# So we might as well run it in background and ignore the output
	log-output -t installation-progress \
		wget -nv -a $installation_progress_log -b -O /dev/null \
		--method PATCH \
		--header 'Content-Type: text/plain' \
		--body-data "status='$status'" \
		"$url" \
	|| installation_progress_warn "wget failed"
}

installation_progress()
{
	local method

	db_get installation-progress/method || return
	method="$RET"

	case $method in
		http)
			installation_progress_http "$@"
			;;
		*)
			installation_progress_warn "Invalid method: $method"
	esac
}
